/**
 * INOS — Infinite Network Operating System
 * The living backbone of theinfinitenetwork.com
 *
 * SoT: LDRP-2:2-YYYYMMDD-TEAMAI
 * Owner: L. D. Ross (LDR)  |  Custodian: ARC  |  Ops Overseer: WAR
 *
 * Architecture:
 *   - Timeline  : Immutable ledger of all PoLEs, decisions, milestones
 *   - Wallet    : TCR balance, Sovereign Score, badges per user
 *   - PoLE      : Proof-of-Living Events (declare → attest → mint)
 *   - Guilds    : Purpose communities that verify and reward
 *   - Audit     : Randomized integrity checks with slashing
 *   - MCP       : Core command ops (AIM routing, WAR missions, ARC specs)
 *   - INOS Shell: Command-line style API for power users / agents
 *
 * The epoch begins with us.
 */

import { DurableObject } from "cloudflare:workers";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface Env {
  // Durable Objects
  TIMELINE: DurableObjectNamespace;
  WALLET: DurableObjectNamespace;
  GUILD: DurableObjectNamespace;

  // D1 — canonical relational brain
  BRAIN: D1Database;

  // KV — fast-path config + active session cache
  CONFIG: KVNamespace;

  // R2 — evidence vault (photos, documents, PoLE artifacts)
  VAULT: R2Bucket;

  // Analytics — sovereign telemetry
  TELEMETRY: AnalyticsEngineDataset;

  // Queues — async PoLE processing + audit pipeline
  POLE_QUEUE: Queue;
  AUDIT_QUEUE: Queue;

  // Secrets
  NOTION_API_KEY: string;
  NOTION_TIMELINE_DB_ID: string;
  NOTION_TASKS_DB_ID: string;
  INTERNAL_API_KEY: string;

  // Config vars
  ENVIRONMENT: string; // "production" | "dev"
  DOMAIN: string;      // "theinfinitenetwork.com"
}

// PoLE categories — the five pillars of intentional living
type PoLECategory =
  | "deep_work"
  | "recovery"
  | "stewardship"
  | "social"
  | "mastery";

// Verification phase mirrors the Infinite Network roadmap
type VerificationPhase = "option_b" | "option_a";

interface PoLESubmission {
  actor_did: string;
  category: PoLECategory;
  intent: string;
  start_time: string; // ISO 8601
  end_time: string;
  evidence_refs?: string[]; // R2 keys or text notes
  privacy_level?: "public" | "guild" | "private";
  guild_id?: string;
  mode?: string; // Time Mode active during this PoLE
}

interface TimelineEntry {
  entry_id: string;
  when: string;
  type: "Mission" | "Decision" | "Milestone" | "Incident" | "PoLE" | "Audit" | "Error";
  who: string;
  room: string;
  references?: string;
  entry: string;
  immutable: boolean;
  hash?: string; // SHA-256 of content for vault seal
}

interface WalletState {
  did: string;
  tcr_balance: number;
  sovereign_score: number;
  badges: string[];
  pole_count: number;
  streak_days: number;
  last_active: string;
  guilds: string[];
  privacy_tier: "public" | "selective" | "private";
}

interface MissionBrief {
  mission_id: string;
  objective: string;
  stage: "Planning" | "Active" | "Review" | "Complete" | "Archived";
  priority: "Critical" | "High" | "Medium" | "Low";
  team: string[];
  deadline?: string;
  contingencies?: string;
  entity: string; // IE | FFC | GGP | CNGI
  pod: string;    // creative_delivery | knowledge_ops | rd_systems_ip | culture_human
}

// ─── TIMELINE Durable Object ──────────────────────────────────────────────────
// Immutable ledger — extend-only, never delete, never overwrite

export class TimelineDO extends DurableObject {
  private storage: DurableObjectStorage;

  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    this.storage = ctx.storage;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // POST /append — log a new immutable entry
    if (request.method === "POST" && path === "/append") {
      return this.appendEntry(await request.json() as Partial<TimelineEntry>);
    }

    // GET /entries — paginated read
    if (request.method === "GET" && path === "/entries") {
      const limit = parseInt(url.searchParams.get("limit") ?? "50");
      const cursor = url.searchParams.get("cursor") ?? undefined;
      return this.getEntries(limit, cursor);
    }

    // GET /search — keyword scan (simple, no vector needed yet)
    if (request.method === "GET" && path === "/search") {
      const q = url.searchParams.get("q") ?? "";
      return this.searchEntries(q);
    }

    return Response.json({ error: "Not found" }, { status: 404 });
  }

  private async appendEntry(data: Partial<TimelineEntry>): Promise<Response> {
    const counter = ((await this.storage.get<number>("counter")) ?? 0) + 1;
    const year = new Date().getFullYear();

    const entry: TimelineEntry = {
      entry_id: `TLM-${year}-${String(counter).padStart(4, "0")}`,
      when: data.when ?? new Date().toISOString(),
      type: data.type ?? "Milestone",
      who: data.who ?? "SYSTEM",
      room: data.room ?? "CORE",
      references: data.references,
      entry: data.entry ?? "",
      immutable: true,
    };

    // Compute content hash for vault seal integrity
    const content = JSON.stringify(entry);
    const hashBuffer = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(content)
    );
    entry.hash = Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");

    // Persist — key by entry_id for indexed retrieval
    await this.storage.put(`entry:${entry.entry_id}`, entry);
    await this.storage.put("counter", counter);

    // Maintain a sorted index (most recent last)
    const index = (await this.storage.get<string[]>("index")) ?? [];
    index.push(entry.entry_id);
    await this.storage.put("index", index);

    return Response.json({ ok: true, entry_id: entry.entry_id, hash: entry.hash });
  }

  private async getEntries(limit: number, cursor?: string): Promise<Response> {
    const index = (await this.storage.get<string[]>("index")) ?? [];
    const start = cursor ? index.indexOf(cursor) + 1 : Math.max(0, index.length - limit);
    const slice = index.slice(start, start + limit);
    const entries = await Promise.all(
      slice.map((id) => this.storage.get<TimelineEntry>(`entry:${id}`))
    );
    return Response.json({
      entries: entries.filter(Boolean),
      next_cursor: slice[slice.length - 1],
      total: index.length,
    });
  }

  private async searchEntries(query: string): Promise<Response> {
    const index = (await this.storage.get<string[]>("index")) ?? [];
    const results: TimelineEntry[] = [];
    const q = query.toLowerCase();
    // Scan last 200 entries (sufficient for MVP; upgrade to Vectorize in Alpha)
    const scan = index.slice(-200).reverse();
    for (const id of scan) {
      const e = await this.storage.get<TimelineEntry>(`entry:${id}`);
      if (e && (e.entry.toLowerCase().includes(q) || e.who.toLowerCase().includes(q))) {
        results.push(e);
        if (results.length >= 20) break;
      }
    }
    return Response.json({ results, query });
  }
}

// ─── WALLET Durable Object ────────────────────────────────────────────────────
// Per-user sovereign state: TCR, Sovereign Score, badges, streaks

export class WalletDO extends DurableObject {
  private storage: DurableObjectStorage;

  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    this.storage = ctx.storage;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === "GET" && path === "/state") {
      return this.getState();
    }
    if (request.method === "POST" && path === "/mint") {
      const { tcr, ss_delta, badge } = await request.json() as {
        tcr?: number;
        ss_delta?: number;
        badge?: string;
      };
      return this.mint(tcr ?? 0, ss_delta ?? 0, badge);
    }
    if (request.method === "POST" && path === "/init") {
      return this.initWallet(await request.json() as { did: string });
    }
    if (request.method === "POST" && path === "/slash") {
      const { ss_loss, reason } = await request.json() as { ss_loss: number; reason: string };
      return this.slash(ss_loss, reason);
    }
    return Response.json({ error: "Not found" }, { status: 404 });
  }

  private async getState(): Promise<Response> {
    const state = await this.storage.get<WalletState>("wallet");
    if (!state) return Response.json({ error: "Wallet not initialized" }, { status: 404 });
    return Response.json(state);
  }

  private async initWallet(data: { did: string }): Promise<Response> {
    const existing = await this.storage.get<WalletState>("wallet");
    if (existing) return Response.json({ ok: true, already_exists: true, wallet: existing });
    const wallet: WalletState = {
      did: data.did,
      tcr_balance: 0,
      sovereign_score: 100, // Epoch Zero starting score
      badges: ["epoch_zero_founder"],
      pole_count: 0,
      streak_days: 0,
      last_active: new Date().toISOString(),
      guilds: [],
      privacy_tier: "selective",
    };
    await this.storage.put("wallet", wallet);
    return Response.json({ ok: true, wallet });
  }

  private async mint(tcr: number, ss_delta: number, badge?: string): Promise<Response> {
    const wallet = await this.storage.get<WalletState>("wallet");
    if (!wallet) return Response.json({ error: "Wallet not initialized" }, { status: 404 });

    wallet.tcr_balance += tcr;
    wallet.sovereign_score = Math.max(0, Math.min(1000, wallet.sovereign_score + ss_delta));
    wallet.pole_count++;
    wallet.last_active = new Date().toISOString();
    if (badge && !wallet.badges.includes(badge)) wallet.badges.push(badge);

    // Streak logic: check if within 25h of last_active
    const lastMs = new Date(wallet.last_active).getTime();
    const nowMs = Date.now();
    if (nowMs - lastMs < 25 * 60 * 60 * 1000) {
      wallet.streak_days++;
    } else {
      wallet.streak_days = 1;
    }

    await this.storage.put("wallet", wallet);
    return Response.json({ ok: true, wallet });
  }

  private async slash(ss_loss: number, reason: string): Promise<Response> {
    const wallet = await this.storage.get<WalletState>("wallet");
    if (!wallet) return Response.json({ error: "Wallet not found" }, { status: 404 });
    wallet.sovereign_score = Math.max(0, wallet.sovereign_score - ss_loss);
    await this.storage.put("wallet", wallet);
    return Response.json({ ok: true, slashed: ss_loss, reason, new_ss: wallet.sovereign_score });
  }
}

// ─── GUILD Durable Object ─────────────────────────────────────────────────────
// Purpose communities — verify PoLEs, issue quests, award guild badges

export class GuildDO extends DurableObject {
  private storage: DurableObjectStorage;

  constructor(ctx: DurableObjectState, env: Env) {
    super(ctx, env);
    this.storage = ctx.storage;
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    if (request.method === "GET" && path === "/info") {
      return Response.json(await this.storage.get("guild") ?? { error: "Guild not found" });
    }
    if (request.method === "POST" && path === "/attest") {
      return this.attestPoLE(await request.json() as { pole_id: string; verifier_did: string; verdict: "pass" | "fail" });
    }
    if (request.method === "POST" && path === "/init") {
      return this.initGuild(await request.json() as { id: string; name: string; type: string; standards: string[] });
    }
    return Response.json({ error: "Not found" }, { status: 404 });
  }

  private async initGuild(data: { id: string; name: string; type: string; standards: string[] }): Promise<Response> {
    const guild = { ...data, member_count: 0, verification_count: 0, created_at: new Date().toISOString() };
    await this.storage.put("guild", guild);
    return Response.json({ ok: true, guild });
  }

  private async attestPoLE(data: { pole_id: string; verifier_did: string; verdict: "pass" | "fail" }): Promise<Response> {
    const guild = await this.storage.get<Record<string, unknown>>("guild");
    const count = ((await this.storage.get<number>("verification_count")) ?? 0) + 1;
    await this.storage.put("verification_count", count);
    return Response.json({ ok: true, pole_id: data.pole_id, verdict: data.verdict, count });
  }
}

// ─── Main Worker ──────────────────────────────────────────────────────────────

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    // CORS — allow theinfinitenetwork.com and localhost for dev
    const origin = request.headers.get("Origin") ?? "";
    const allowed = [
      `https://${env.DOMAIN}`,
      `https://www.${env.DOMAIN}`,
      "http://localhost:5173",
      "http://localhost:3000",
    ];
    const corsHeaders: Record<string, string> = {
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-INOS-Key",
      "Access-Control-Max-Age": "86400",
    };
    if (allowed.includes(origin)) corsHeaders["Access-Control-Allow-Origin"] = origin;
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders });

    const respond = (body: unknown, status = 200) =>
      Response.json(body, { status, headers: corsHeaders });

    try {
      const url = new URL(request.url);
      const [, version, ...segments] = url.pathname.split("/");
      const path = segments.join("/");

      if (version !== "v1") return respond({ error: "Use /v1/" }, 404);

      // ── Auth guard for write operations ─────────────────────────────────
      if (request.method !== "GET") {
        const key = request.headers.get("Authorization")?.replace("Bearer ", "") ?? "";
        if (!key) return respond({ error: "Authorization required" }, 401);
        // In production: validate JWT or DID-signed token
        // For Epoch Zero MVP: validate against INTERNAL_API_KEY or KV session store
        const valid = await env.CONFIG.get(`session:${key}`);
        if (!valid && key !== env.INTERNAL_API_KEY) {
          return respond({ error: "Invalid or expired token" }, 403);
        }
      }

      // ─ Route table ───────────────────────────────────────────────────────

      // POST /v1/pole — submit a Proof-of-Living Event
      if (path === "pole" && request.method === "POST") {
        return handleSubmitPoLE(request, env, respond);
      }

      // POST /v1/attest — guild verifier attests a PoLE
      if (path === "attest" && request.method === "POST") {
        return handleAttest(request, env, ctx, respond);
      }

      // GET /v1/wallet — get a user's Time Wallet
      if (path === "wallet" && request.method === "GET") {
        const did = url.searchParams.get("did");
        if (!did) return respond({ error: "did required" }, 400);
        return getWallet(did, env, respond);
      }

      // POST /v1/wallet/init — initialize a new wallet
      if (path === "wallet/init" && request.method === "POST") {
        const { did } = await request.json() as { did: string };
        const stub = env.WALLET.get(env.WALLET.idFromName(did));
        const res = await stub.fetch(new Request("https://wallet/init", {
          method: "POST",
          body: JSON.stringify({ did }),
          headers: { "Content-Type": "application/json" },
        }));
        return respond(await res.json());
      }

      // GET /v1/timeline — read the immutable ledger
      if (path === "timeline" && request.method === "GET") {
        return getTimeline(url, env, respond);
      }

      // GET /v1/timeline/search — search the Timeline
      if (path === "timeline/search" && request.method === "GET") {
        const q = url.searchParams.get("q") ?? "";
        const stub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
        const res = await stub.fetch(new Request(`https://timeline/search?q=${encodeURIComponent(q)}`));
        return respond(await res.json());
      }

      // POST /v1/mission — create a WAR mission (TEAM AI integration)
      if (path === "mission" && request.method === "POST") {
        return handleMission(request, env, ctx, respond);
      }

      // GET /v1/guild/:id — get guild info
      if (path.startsWith("guild/") && request.method === "GET") {
        const guildId = path.replace("guild/", "");
        const stub = env.GUILD.get(env.GUILD.idFromName(guildId));
        const res = await stub.fetch(new Request("https://guild/info"));
        return respond(await res.json());
      }

      // POST /v1/guild/init — create a new guild
      if (path === "guild/init" && request.method === "POST") {
        return handleGuildInit(request, env, respond);
      }

      // GET /v1/audit/trigger — trigger a randomized integrity audit
      if (path === "audit/trigger" && request.method === "GET") {
        return triggerAudit(env, respond);
      }

      // GET /v1/health — system health check
      if (path === "health" && request.method === "GET") {
        return respond({
          status: "operational",
          system: "INOS",
          version: "2.2",
          domain: env.DOMAIN,
          environment: env.ENVIRONMENT,
          timestamp: new Date().toISOString(),
          war_cry: "The epoch begins with us.",
        });
      }

      // INOS Shell command endpoint — power user / agent interface
      // POST /v1/shell — issue TEAM AI / INOS commands
      if (path === "shell" && request.method === "POST") {
        return handleShell(request, env, ctx, respond);
      }

      return respond({ error: "Not found", path }, 404);
    } catch (err) {
      console.error("INOS Worker Error:", err);
      return Response.json({ error: "Internal server error" }, { status: 500, headers: corsHeaders });
    }
  },

  // ── Async queue consumer: PoLE processing ─────────────────────────────────
  async queue(batch: MessageBatch<unknown>, env: Env): Promise<void> {
    for (const msg of batch.messages) {
      try {
        const data = msg.body as { type: "pole" | "audit"; payload: unknown };

        if (data.type === "pole") {
          await processPoleAsync(data.payload as PoLESubmission & { pole_id: string }, env);
        } else if (data.type === "audit") {
          await processAuditAsync(data.payload as { pole_id: string; actor_did: string }, env);
        }

        msg.ack();
      } catch (err) {
        console.error("Queue processing error:", err);
        msg.retry();
      }
    }
  },
} satisfies ExportedHandler<Env>;

// ─── Handler Functions ────────────────────────────────────────────────────────

/**
 * handleSubmitPoLE
 * User declares intent → system validates → queues for attestation
 * This is the heart of Proof of Living (Option B — peer-verified MVP)
 */
async function handleSubmitPoLE(
  request: Request,
  env: Env,
  respond: (body: unknown, status?: number) => Response
): Promise<Response> {
  const data = await request.json() as PoLESubmission;

  // Input validation
  if (!data.actor_did) return respond({ error: "actor_did required" }, 400);
  if (!data.category) return respond({ error: "category required" }, 400);
  if (!data.intent) return respond({ error: "intent required" }, 400);
  if (!data.start_time || !data.end_time) return respond({ error: "start_time and end_time required" }, 400);

  // Sanity check: end must be after start and within 24h (anti-gaming)
  const start = new Date(data.start_time).getTime();
  const end = new Date(data.end_time).getTime();
  if (end <= start) return respond({ error: "end_time must be after start_time" }, 400);
  if (end - start > 24 * 60 * 60 * 1000) return respond({ error: "PoLE cannot exceed 24 hours" }, 400);

  // Generate PoLE ID
  const pole_id = `POLE-${Date.now()}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;

  // Store evidence refs in R2 vault if provided
  if (data.evidence_refs?.length) {
    // In production: validate each ref is an authorized R2 key belonging to this DID
    // For MVP: we accept refs as submitted (peer review confirms authenticity)
  }

  // Log submission to Timeline (immediate, synchronous)
  const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
  await timelineStub.fetch(new Request("https://timeline/append", {
    method: "POST",
    body: JSON.stringify({
      type: "PoLE",
      who: data.actor_did,
      room: data.guild_id ? `GUILD:${data.guild_id}` : "OPEN",
      references: pole_id,
      entry: `PoLE submitted: [${data.category.toUpperCase()}] "${data.intent}" (${Math.round((end - start) / 60000)}m)`,
    }),
    headers: { "Content-Type": "application/json" },
  }));

  // Store pending PoLE in KV for fast lookup during attestation
  await env.CONFIG.put(
    `pole:pending:${pole_id}`,
    JSON.stringify({ ...data, pole_id, status: "pending", submitted_at: new Date().toISOString() }),
    { expirationTtl: 7 * 24 * 60 * 60 } // pending expires in 7 days if not attested
  );

  // Queue for async processing (verification routing, SS pre-calculation)
  await env.POLE_QUEUE.send({ type: "pole", payload: { ...data, pole_id } });

  // Telemetry — non-blocking
  env.TELEMETRY.writeDataPoint({
    blobs: [data.category, data.actor_did.slice(0, 8), data.privacy_level ?? "selective"],
    doubles: [(end - start) / 60000], // duration in minutes
    indexes: [data.actor_did],
  });

  return respond({
    ok: true,
    pole_id,
    status: "pending_verification",
    message: "Your PoLE has been submitted. Guild verification pending.",
    next: data.guild_id
      ? `Awaiting attestation from guild ${data.guild_id}`
      : "Awaiting peer verification",
  });
}

/**
 * handleAttest
 * Verifier (guild member or peer) attests a pending PoLE
 * Verifier weight is proportional to Sovereign Score (anti-gaming)
 */
async function handleAttest(
  request: Request,
  env: Env,
  ctx: ExecutionContext,
  respond: (body: unknown, status?: number) => Response
): Promise<Response> {
  const { pole_id, verifier_did, verdict, reason } = await request.json() as {
    pole_id: string;
    verifier_did: string;
    verdict: "pass" | "fail";
    reason?: string;
  };

  if (!pole_id || !verifier_did || !verdict) {
    return respond({ error: "pole_id, verifier_did, verdict required" }, 400);
  }

  // Fetch pending PoLE
  const raw = await env.CONFIG.get(`pole:pending:${pole_id}`);
  if (!raw) return respond({ error: "PoLE not found or already processed" }, 404 );

  const pole = JSON.parse(raw) as PoLESubmission & { pole_id: string; submitted_at: string };

  // Fetch verifier wallet to get their Sovereign Score (determines weight)
  const verifierWalletStub = env.WALLET.get(env.WALLET.idFromName(verifier_did));
  const verifierRes = await verifierWalletStub.fetch(new Request("https://wallet/state"));
  const verifierWallet = verifierRes.ok ? (await verifierRes.json() as WalletState) : null;
  const verifierWeight = verifierWallet ? Math.min(5, Math.floor(verifierWallet.sovereign_score / 200) + 1) : 1;

  if (verdict === "pass") {
    // Calculate TCR reward: base 10 + quality multipliers
    const durationMin = (new Date(pole.end_time).getTime() - new Date(pole.start_time).getTime()) / 60000;
    const durationBonus = Math.min(10, Math.floor(durationMin / 30));
    const tcr_reward = 10 + durationBonus;
    const ss_delta = 2 + verifierWeight;

    // Mint TCR and update SS in actor's wallet
    ctx.waitUntil((async () => {
      const actorStub = env.WALLET.get(env.WALLET.idFromName(pole.actor_did));
      await actorStub.fetch(new Request("https://wallet/mint", {
        method: "POST",
        body: JSON.stringify({ tcr: tcr_reward, ss_delta, badge: undefined }),
        headers: { "Content-Type": "application/json" },
      }));

      // Log to Timeline
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      await timelineStub.fetch(new Request("https://timeline/append", {
        method: "POST",
        body: JSON.stringify({
          type: "PoLE",
          who: verifier_did,
          room: `ATTEST`,
          references: pole_id,
          entry: `PoLE VERIFIED [${pole.category}] by ${verifier_did} (weight ${verifierWeight}) → +${tcr_reward} TCR, +${ss_delta} SS for ${pole.actor_did}`,
        }),
        headers: { "Content-Type": "application/json" },
      }));
    })());

    // Mark PoLE as verified
    await env.CONFIG.put(`pole:verified:${pole_id}`, JSON.stringify({ ...pole, status: "verified", verifier_did, verdict, verified_at: new Date().toISOString() }));
    await env.CONFIG.delete(`pole:pending:${pole_id}`);

    // Random audit trigger (~10% of verified PoLEs get a deeper audit)
    if (Math.random() < 0.10) {
      await env.AUDIT_QUEUE.send({ type: "audit", payload: { pole_id, actor_did: pole.actor_did } });
    }

    return respond({ ok: true, verdict: "pass", tcr_reward, ss_delta, pole_id });
  } else {
    // Failed attestation — slash actor SS slightly, log incident
    ctx.waitUntil((async () => {
      const actorStub = env.WALLET.get(env.WALLET.idFromName(pole.actor_did));
      await actorStub.fetch(new Request("https://wallet/slash", {
        method: "POST",
        body: JSON.stringify({ ss_loss: 5, reason: reason ?? "Failed attestation" }),
        headers: { "Content-Type": "application/json" },
      }));
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      await timelineStub.fetch(new Request("https://timeline/append", {
        method: "POST",
        body: JSON.stringify({
          type: "Incident",
          who: verifier_did,
          room: "AUDIT",
          references: pole_id,
          entry: `PoLE REJECTED [${pole.category}] by ${verifier_did} — Reason: ${reason ?? "unspecified"} → -5 SS for ${pole.actor_did}`,
        }),
        headers: { "Content-Type": "application/json" },
      }));
    })());

    await env.CONFIG.delete(`pole:pending:${pole_id}`);
    return respond({ ok: true, verdict: "fail", pole_id, reason });
  }
}

/**
 * handleMission
 * WAR pod integration — create a TEAM AI mission
 * Logs to both INOS Timeline and optionally syncs to Notion via MCP
 */
async function handleMission(
  request: Request,
  env: Env,
  ctx: ExecutionContext,
  respond: (body: unknown, status?: number) => Response
): Promise<Response> {
  const brief = await request.json() as Partial<MissionBrief>;

  if (!brief.objective) return respond({ error: "objective required" }, 400);

  const mission_id = `MSN-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
  const mission: MissionBrief = {
    mission_id,
    objective: brief.objective,
    stage: "Planning",
    priority: brief.priority ?? "Medium",
    team: brief.team ?? ["WAR", "AIM"],
    deadline: brief.deadline,
    entity: brief.entity ?? "IE",
    pod: brief.pod ?? "knowledge_ops",
  };

  // Store in KV
  await env.CONFIG.put(`mission:${mission_id}`, JSON.stringify(mission));

  // Log to Timeline
  ctx.waitUntil((async () => {
    const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
    await timelineStub.fetch(new Request("https://timeline/append", {
      method: "POST",
      body: JSON.stringify({
        type: "Mission",
        who: "WAR",
        room: mission.pod,
        references: mission_id,
        entry: `Mission opened: ${mission.objective} [${mission.entity} | ${mission.priority}]`,
      }),
      headers: { "Content-Type": "application/json" },
    }));

    // Sync to Notion if keys are configured
    if (env.NOTION_API_KEY && env.NOTION_TASKS_DB_ID) {
      await syncMissionToNotion(mission, env);
    }
  })());

  return respond({ ok: true, mission_id, mission, message: "Mission is live. WAR has the watch." });
}

/**
 * handleGuildInit — create a new Founding Guild
 */
async function handleGuildInit(
  request: Request,
  env: Env,
  respond: (body: unknown, status?: number) => Response
): Promise<Response> {
  const data = await request.json() as { id: string; name: string; type: string; standards?: string[] };
  if (!data.id || !data.name) return respond({ error: "id and name required" }, 400);

  const stub = env.GUILD.get(env.GUILD.idFromName(data.id));
  const res = await stub.fetch(new Request("https://guild/init", {
    method: "POST",
    body: JSON.stringify({ ...data, standards: data.standards ?? [] }),
    headers: { "Content-Type": "application/json" },
  }));

  const result = await res.json();

  // Log founding to Timeline
  const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
  await timelineStub.fetch(new Request("https://timeline/append", {
    method: "POST",
    body: JSON.stringify({
      type: "Milestone",
      who: "SYSTEM",
      room: "GUILD",
      references: data.id,
      entry: `Founding Guild created: "${data.name}" (${data.type}) — Epoch Zero Charter activated`,
    }),
    headers: { "Content-Type": "application/json" },
  }));

  return respond({ ok: true, ...result });
}

/**
 * handleShell — INOS Shell command interface
 * Power users and TEAM AI agents (AIM, WAR, ARC) issue commands here
 * Syntax: { command: "COMMAND_NAME", payload: {...} }
 */
async function handleShell(
  request: Request,
  env: Env,
  ctx: ExecutionContext,
  respond: (body: unknown, status?: number) => Response
): Promise<Response> {
  const { command, payload } = await request.json() as { command: string; payload?: unknown };

  // TEAM AI command codes
  const commands: Record<string, string> = {
    "STATUS": "Returns current system state",
    "HARD_BRAKE": "Emergency stop — pauses all agent activity",
    "GREENLIGHT": "Resumes operations after HARD_BRAKE",
    "TIMELINE_APPEND": "Appends an entry to the immutable Timeline",
    "WALLET_MINT": "Mints TCR to a wallet",
    "MISSION_CREATE": "Creates a new WAR mission",
    "GUILD_ATTEST": "Submits a guild attestation",
    "AUDIT_TRIGGER": "Triggers a manual audit",
  };

  switch (command) {
    case "STATUS": {
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      const tlRes = await timelineStub.fetch(new Request("https://timeline/entries?limit=5"));
      const tl = await tlRes.json() as { total: number };
      return respond({
        ok: true,
        system: "INOS v2.2",
        domain: env.DOMAIN,
        environment: env.ENVIRONMENT,
        timeline_entries: tl.total,
        war_cry: "The epoch begins with us.",
        available_commands: Object.keys(commands),
      });
    }

    case "HARD_BRAKE": {
      await env.CONFIG.put("system:hard_brake", "1", { expirationTtl: 3600 });
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      await timelineStub.fetch(new Request("https://timeline/append", {
        method: "POST",
        body: JSON.stringify({
          type: "Decision",
          who: "SYSTEM",
          room: "CORE",
          entry: "HARD BRAKE activated. All agent activity paused pending human review.",
        }),
        headers: { "Content-Type": "application/json" },
      }));
      return respond({ ok: true, status: "HARD_BRAKE_ACTIVE", message: "All systems paused. Issue GREENLIGHT to resume." });
    }

    case "GREENLIGHT": {
      await env.CONFIG.delete("system:hard_brake");
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      await timelineStub.fetch(new Request("https://timeline/append", {
        method: "POST",
        body: JSON.stringify({
          type: "Decision",
          who: "SYSTEM",
          room: "CORE",
          entry: "GREENLIGHT issued. Systems resuming normal operation.",
        }),
        headers: { "Content-Type": "application/json" },
      }));
      return respond({ ok: true, status: "OPERATIONAL", message: "Systems back online. All gas, no brakes." });
    }

    case "TIMELINE_APPEND": {
      const p = payload as Partial<TimelineEntry>;
      const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
      const res = await timelineStub.fetch(new Request("https://timeline/append", {
        method: "POST",
        body: JSON.stringify(p),
        headers: { "Content-Type": "application/json" },
      }));
      return respond(await res.json());
    }

    default:
      return respond({ error: `Unknown command: ${command}`, available: Object.keys(commands) }, 400);
  }
}

// ─── Helper Functions ─────────────────────────────────────────────────────────

async function getWallet(did: string, env: Env, respond: (b: unknown, s?: number) => Response): Promise<Response> {
  const stub = env.WALLET.get(env.WALLET.idFromName(did));
  const res = await stub.fetch(new Request("https://wallet/state"));
  if (!res.ok) return respond({ error: "Wallet not found" }, 404);
  return respond(await res.json());
}

async function getTimeline(url: URL, env: Env, respond: (b: unknown, s?: number) => Response): Promise<Response> {
  const limit = parseInt(url.searchParams.get("limit") ?? "50");
  const cursor = url.searchParams.get("cursor") ?? undefined;
  const stub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
  const params = new URLSearchParams({ limit: String(limit) });
  if (cursor) params.set("cursor", cursor);
  const res = await stub.fetch(new Request(`https://timeline/entries?${params}`));
  return respond(await res.json());
}

async function triggerAudit(env: Env, respond: (b: unknown, s?: number) => Response): Promise<Response> {
  // Randomly sample from recently verified PoLEs for integrity audit
  const auditId = `AUDIT-${Date.now()}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`;
  // In production: query D1 for recent verified PoLEs, randomly select
  // For MVP: log the audit trigger to Timeline
  const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
  await timelineStub.fetch(new Request("https://timeline/append", {
    method: "POST",
    body: JSON.stringify({
      type: "Audit",
      who: "SYSTEM",
      room: "AUDIT",
      references: auditId,
      entry: `Random integrity audit triggered: ${auditId}. Anti-gaming checkpoint active.`,
    }),
    headers: { "Content-Type": "application/json" },
  }));
  return respond({ ok: true, audit_id: auditId, message: "Audit queued. Anti-gaming checks in motion." });
}

async function processPoleAsync(pole: PoLESubmission & { pole_id: string }, env: Env): Promise<void> {
  // Phase 1 (Option B): route to guild for peer verification
  // Future Phase 2: device signal hooks, geofence checks, app integrations
  if (pole.guild_id) {
    const stub = env.GUILD.get(env.GUILD.idFromName(pole.guild_id));
    await stub.fetch(new Request("https://guild/attest", {
      method: "POST",
      body: JSON.stringify({ pole_id: pole.pole_id, verifier_did: `GUILD:${pole.guild_id}`, verdict: "pending" }),
      headers: { "Content-Type": "application/json" },
    }));
  }
  // Log to D1 for persistent relational queries
  // await env.BRAIN.prepare("INSERT INTO poles (id, actor_did, category, intent, start_time, end_time, status) VALUES (?,?,?,?,?,?,?)")
  //   .bind(pole.pole_id, pole.actor_did, pole.category, pole.intent, pole.start_time, pole.end_time, "pending")
  //   .run();
}

async function processAuditAsync(data: { pole_id: string; actor_did: string }, env: Env): Promise<void> {
  // Integrity audit: cross-check evidence, timing patterns, verifier quality
  // For MVP: log the audit initiation; escalate anomalies to Timeline
  const timelineStub = env.TIMELINE.get(env.TIMELINE.idFromName("canonical"));
  await timelineStub.fetch(new Request("https://timeline/append", {
    method: "POST",
    body: JSON.stringify({
      type: "Audit",
      who: "SYSTEM",
      room: "AUDIT",
      references: data.pole_id,
      entry: `Integrity audit initiated for ${data.actor_did} — PoLE ${data.pole_id}. Pattern analysis in progress.`,
    }),
    headers: { "Content-Type": "application/json" },
  }));
}

/**
 * syncMissionToNotion — TEAM AI MCP bridge
 * Writes WAR missions back to the canonical Notion brain
 */
async function syncMissionToNotion(mission: MissionBrief, env: Env): Promise<void> {
  try {
    await fetch(`https://api.notion.com/v1/pages`, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${env.NOTION_API_KEY}`,
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        parent: { database_id: env.NOTION_TASKS_DB_ID },
        properties: {
          Mission: { title: [{ text: { content: mission.mission_id } }] },
          Objective: { rich_text: [{ text: { content: mission.objective } }] },
          Stage: { select: { name: mission.stage } },
          Priority: { select: { name: mission.priority } },
        },
      }),
    });
  } catch (err) {
    console.error("Notion sync failed (non-fatal):", err);
  }
}
