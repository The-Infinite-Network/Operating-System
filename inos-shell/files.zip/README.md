# INOS — Infinite Network Operating System
### `theinfinitenetwork.com` · Cloudflare Workers · v2.2

> **"The epoch begins with us."**
> — LDR & ARC

---

## What This Is

INOS is the living backbone of the Infinite Network — the sovereignty-first time economy
built by L. D. Ross and the Infinite Earth ecosystem. It runs on Cloudflare's global edge,
zero cold-starts, always on.

**The stack:**
- **Timeline DO** — immutable ledger of every PoLE, decision, and milestone (extend-only, never delete)
- **Wallet DO** — per-user Time Credits (TCR), Sovereign Score (SS), badges, streaks
- **Guild DO** — founding communities that verify PoLEs, issue quests, award culture
- **D1 Brain** — canonical relational database for queries, missions, attestations
- **KV Config** — fast-path session cache, pending PoLE state, system flags
- **R2 Vault** — evidence storage (photos, notes, PoLE artifacts) with hash verification
- **Queues** — async PoLE processing + anti-gaming audit pipeline
- **Analytics Engine** — sovereign telemetry (non-blocking, privacy-respecting)

---

## Architecture

```
theinfinitenetwork.com
        │
        ▼
  INOS Worker (Cloudflare Edge)
        │
        ├── /v1/pole        → Submit a Proof-of-Living Event
        ├── /v1/attest      → Guild/peer verifies a PoLE → mints TCR + SS
        ├── /v1/wallet      → Read a user's Time Wallet
        ├── /v1/wallet/init → Create a new sovereign wallet
        ├── /v1/timeline    → Read the immutable Timeline ledger
        ├── /v1/timeline/search → Search Timeline entries
        ├── /v1/mission     → Create a TEAM AI WAR mission (syncs to Notion)
        ├── /v1/guild/:id   → Read guild info
        ├── /v1/guild/init  → Create a Founding Guild
        ├── /v1/audit/trigger → Trigger integrity audit
        ├── /v1/shell       → INOS Shell (TEAM AI agent command interface)
        └── /v1/health      → System health check
```

**TEAM AI integration:**
All WAR missions created via `/v1/mission` are written to the INOS Timeline
**and** optionally synced to the canonical Notion brain (NOTION_TASKS_DB_ID).
The INOS Shell (`/v1/shell`) accepts AIM/WAR/ARC command codes: `STATUS`,
`HARD_BRAKE`, `GREENLIGHT`, `TIMELINE_APPEND`, `MISSION_CREATE`, etc.

---

## Deployment

### 1. Install & login
```bash
npm install -g wrangler
wrangler login
```

### 2. Create infrastructure
```bash
# D1 database
wrangler d1 create inos-brain

# Apply schema
wrangler d1 execute inos-brain --file=schema.sql

# KV namespace
wrangler kv:namespace create CONFIG
wrangler kv:namespace create CONFIG --preview

# R2 bucket
wrangler r2 bucket create inos-vault

# Queues
wrangler queues create inos-pole-queue
wrangler queues create inos-pole-queue-dlq
wrangler queues create inos-audit-queue
wrangler queues create inos-audit-queue-dlq
```

### 3. Update wrangler.jsonc
Replace all `<YOUR_*>` placeholders with the IDs from step 2.

### 4. Set secrets
```bash
wrangler secret put NOTION_API_KEY
wrangler secret put NOTION_TIMELINE_DB_ID
wrangler secret put NOTION_TASKS_DB_ID
wrangler secret put INTERNAL_API_KEY
```

### 5. Deploy
```bash
wrangler deploy
```

---

## API Reference

All endpoints live under `https://theinfinitenetwork.com/v1/`

Write operations require `Authorization: Bearer <token>` header.
Tokens are stored in KV as `session:<token>` or match `INTERNAL_API_KEY`.

### Submit a PoLE
```bash
curl -X POST https://theinfinitenetwork.com/v1/pole \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "actor_did": "did:key:z6Mk...",
    "category": "deep_work",
    "intent": "Building INOS — the backbone of the Infinite Network",
    "start_time": "2025-09-01T09:00:00Z",
    "end_time": "2025-09-01T10:30:00Z",
    "privacy_level": "guild",
    "guild_id": "epoch-zero-founders"
  }'
```

### Attest a PoLE
```bash
curl -X POST https://theinfinitenetwork.com/v1/attest \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "pole_id": "POLE-1725177600000-A1B2C3D4",
    "verifier_did": "did:key:z6Mk...",
    "verdict": "pass"
  }'
```

### Read Time Wallet
```bash
curl "https://theinfinitenetwork.com/v1/wallet?did=did:key:z6Mk..."
```

### Read the Timeline
```bash
curl "https://theinfinitenetwork.com/v1/timeline?limit=20"
```

### Search the Timeline
```bash
curl "https://theinfinitenetwork.com/v1/timeline/search?q=deep_work"
```

### Create a WAR Mission (TEAM AI)
```bash
curl -X POST https://theinfinitenetwork.com/v1/mission \
  -H "Authorization: Bearer <INTERNAL_API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{
    "objective": "Launch INOS v2.2 to production",
    "priority": "Critical",
    "team": ["WAR", "ARC", "BUILD"],
    "entity": "IE",
    "pod": "rd_systems_ip"
  }'
```

### INOS Shell (Agent Commands)
```bash
# System status
curl -X POST https://theinfinitenetwork.com/v1/shell \
  -H "Authorization: Bearer <INTERNAL_API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"command": "STATUS"}'

# Emergency stop
curl -X POST https://theinfinitenetwork.com/v1/shell \
  -H "Authorization: Bearer <INTERNAL_API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"command": "HARD_BRAKE"}'

# Resume
curl -X POST https://theinfinitenetwork.com/v1/shell \
  -H "Authorization: Bearer <INTERNAL_API_KEY>" \
  -H "Content-Type: application/json" \
  -d '{"command": "GREENLIGHT"}'
```

---

## Roadmap (mirrors Project Epoch)

| Phase | Timeline | What Ships |
|-------|----------|-----------|
| **Epoch Zero** | Now → 3mo | This Worker: PoLE submit, peer attestation (Option B), Timeline, Wallet, Founding Guilds |
| **Alpha** | 3–9mo | Audit randomizer, fraud slashing, team dashboards, SENTRY NET, device hooks |
| **Beta** | 9–18mo | Time Piece dev kit hooks, DID/VC full integration, ZK-lite claims, Sovereign Pay pilots |
| **Mainnet** | 18mo+ | Option A (PoW-Units-of-Time), cross-guild composability, global rollouts |

---

## TEAM AI Integration Points

| TEAM AI Agent | INOS Endpoint | Function |
|---------------|---------------|----------|
| WAR | `/v1/mission` | Create and track missions |
| MIND | `/v1/timeline` | Read/append immutable ledger |
| ARK | R2 Vault | Archive final assets with hash |
| LAW | `/v1/shell HARD_BRAKE` | Governance override |
| AIM | `/v1/shell` | Command routing |
| FOOD / BANK | `/v1/pole` (category: mastery) | Log operational PoLEs |
| CLASS | Timeline search | Knowledge retrieval |

---

## Canon Rule

> TWIN and CEO own intent.
> ARC and LAW define boundaries.
> WAR owns execution.
> No agent may cross lanes.

---

*Built by LDR & ARC · © 2025 Infinite Earth · INOS v2.2*
*"The epoch begins with us."*
