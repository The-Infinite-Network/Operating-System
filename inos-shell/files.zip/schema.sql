-- INOS Brain — D1 Schema
-- SoT: LDRP-2:2-YYYYMMDD-TEAMAI
-- Owner: L. D. Ross | Custodian: ARC | Ops Overseer: WAR
-- Extend-only: no DELETE on core tables; archive via status field

-- ── Proof-of-Living Events ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS poles (
  id            TEXT PRIMARY KEY,
  actor_did     TEXT NOT NULL,
  category      TEXT NOT NULL CHECK(category IN ('deep_work','recovery','stewardship','social','mastery')),
  intent        TEXT NOT NULL,
  start_time    TEXT NOT NULL,
  end_time      TEXT NOT NULL,
  duration_min  REAL GENERATED ALWAYS AS (
                  (JULIANDAY(end_time) - JULIANDAY(start_time)) * 1440
                ) STORED,
  evidence_refs TEXT,              -- JSON array of R2 keys or text refs
  privacy_level TEXT DEFAULT 'selective' CHECK(privacy_level IN ('public','guild','private')),
  guild_id      TEXT,
  mode          TEXT,              -- Time Mode active during this PoLE
  status        TEXT DEFAULT 'pending' CHECK(status IN ('pending','verified','rejected','audited')),
  tcr_reward    REAL DEFAULT 0,
  ss_delta      REAL DEFAULT 0,
  verifier_did  TEXT,
  verified_at   TEXT,
  submitted_at  TEXT NOT NULL DEFAULT (DATETIME('now')),
  pole_hash     TEXT              -- SHA-256 of content for vault seal
);

CREATE INDEX IF NOT EXISTS idx_poles_actor   ON poles(actor_did);
CREATE INDEX IF NOT EXISTS idx_poles_status  ON poles(status);
CREATE INDEX IF NOT EXISTS idx_poles_category ON poles(category);
CREATE INDEX IF NOT EXISTS idx_poles_guild   ON poles(guild_id);

-- ── Users / DIDs ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  did             TEXT PRIMARY KEY,
  display_name    TEXT,
  created_at      TEXT NOT NULL DEFAULT (DATETIME('now')),
  last_active     TEXT,
  privacy_tier    TEXT DEFAULT 'selective',
  is_epoch_founder INTEGER DEFAULT 0  -- Cohort A / Founding Guild member
);

-- ── Guilds ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS guilds (
  id              TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  type            TEXT NOT NULL,   -- craft | location | service | enterprise
  standards       TEXT,            -- JSON array
  member_count    INTEGER DEFAULT 0,
  verification_count INTEGER DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (DATETIME('now')),
  is_founding     INTEGER DEFAULT 0  -- Epoch Zero founding guild
);

-- ── Guild Members ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS guild_members (
  guild_id    TEXT NOT NULL,
  did         TEXT NOT NULL,
  rank        TEXT DEFAULT 'member',
  joined_at   TEXT NOT NULL DEFAULT (DATETIME('now')),
  PRIMARY KEY (guild_id, did),
  FOREIGN KEY (guild_id) REFERENCES guilds(id),
  FOREIGN KEY (did) REFERENCES users(did)
);

-- ── Attestations ──────────────────────────────────────────────────────────────
-- Immutable record of every verification action
CREATE TABLE IF NOT EXISTS attestations (
  id            TEXT PRIMARY KEY DEFAULT (HEX(RANDOMBLOB(8))),
  pole_id       TEXT NOT NULL,
  verifier_did  TEXT NOT NULL,
  verdict       TEXT NOT NULL CHECK(verdict IN ('pass','fail','pending')),
  weight        REAL DEFAULT 1.0,   -- Proportional to verifier Sovereign Score
  reason        TEXT,
  attested_at   TEXT NOT NULL DEFAULT (DATETIME('now')),
  FOREIGN KEY (pole_id) REFERENCES poles(id)
);

CREATE INDEX IF NOT EXISTS idx_attestations_pole ON attestations(pole_id);

-- ── Missions (TEAM AI WAR sync) ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS missions (
  id          TEXT PRIMARY KEY,
  objective   TEXT NOT NULL,
  stage       TEXT DEFAULT 'Planning',
  priority    TEXT DEFAULT 'Medium',
  team        TEXT,                  -- JSON array of agent/person IDs
  entity      TEXT DEFAULT 'IE',    -- IE | FFC | GGP | CNGI
  pod         TEXT,
  deadline    TEXT,
  contingencies TEXT,
  created_at  TEXT NOT NULL DEFAULT (DATETIME('now')),
  updated_at  TEXT,
  notion_page_id TEXT                -- Sync reference to Notion WAR Missions DB
);

-- ── Audit Log ─────────────────────────────────────────────────────────────────
-- Anti-gaming integrity checks — extend-only
CREATE TABLE IF NOT EXISTS audits (
  id          TEXT PRIMARY KEY DEFAULT (HEX(RANDOMBLOB(8))),
  pole_id     TEXT,
  actor_did   TEXT,
  audit_type  TEXT DEFAULT 'random',  -- random | manual | pattern
  result      TEXT,                   -- pass | fail | escalated
  notes       TEXT,
  triggered_at TEXT NOT NULL DEFAULT (DATETIME('now')),
  resolved_at  TEXT
);

-- ── Badges ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS badges (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  description TEXT,
  category    TEXT,
  tcr_threshold REAL,
  ss_threshold  REAL,
  is_epoch_only INTEGER DEFAULT 0  -- Epoch Zero exclusives
);

-- Seed founding badges
INSERT OR IGNORE INTO badges VALUES
  ('epoch_zero_founder',  'Epoch Zero Founder',  'Joined the Infinite Network in Epoch Zero', 'legacy',     0, 0,   1),
  ('first_pole',          'First PoLE',          'Submitted your first Proof-of-Living Event', 'milestone', 10, 102, 0),
  ('deep_worker',         'Deep Worker',          'Completed 10 verified Deep Work PoLEs',     'mastery',    50, 120, 0),
  ('guild_verifier',      'Guild Verifier',       'Attested 5 peer PoLEs',                     'community',  0,  115, 0),
  ('streak_7',            '7-Day Streak',         'Logged verified PoLEs 7 days in a row',     'discipline', 70, 130, 0),
  ('sovereign_100',       'Sovereign Score 100',  'Reached Sovereign Score of 100',            'reputation', 0,  100, 0);
